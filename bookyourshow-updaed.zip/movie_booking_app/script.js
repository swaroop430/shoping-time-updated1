document.addEventListener("DOMContentLoaded", () => {
  const params = new URLSearchParams(window.location.search);
  const movieName = params.get("movie");
  const summaryDiv = document.getElementById("booking-summary");

  if (movieName && summaryDiv) {
    summaryDiv.innerHTML = `<h2>Booking for: ${movieName}</h2>`;
  }

  const seatsAvailable = 50;
  let seatsLeft = seatsAvailable;
  const seatsSpan = document.getElementById("seats");

  const form = document.getElementById("booking-form");
  if (form) {
    form.addEventListener("submit", function (event) {
      event.preventDefault();
      const tickets = parseInt(form.tickets.value);
      const time = form.time.value;
      const payment = form.payment.value;

      if (tickets > seatsLeft) {
        alert("Not enough seats available.");
        return;
      }

      seatsLeft -= tickets;
      if (seatsSpan) seatsSpan.textContent = seatsLeft;

      document.getElementById("confirmation").innerHTML = `
        <h3>Booking Confirmed!</h3>
        <p>Movie: ${movieName}</p>
        <p>Time: ${time}</p>
        <p>Tickets: ${tickets}</p>
        <p>Payment Method: ${payment}</p>
      `;

      form.reset();
    });
  }
});